FIRE EMBLEM: GENEALOGY OF THE HOLY WAR BINARY TRANSLATION PATCH, V0.5

This is a translation patch for FE Binary, a Japanese romhack of FE4 created by Habana887.bsRoNI. (henceforth "the Binary guy.") So, what does this thing translate?

TRANSLATED:
Playable characters (their names follow my preferences, and if you know me well, you'll know that that involves rigorous discarding of FE13/Heroes poll names. Ced is still dumb.)
Gen 1 enemies. Gen 2 is in English, but it's kind of rough around the edges.
Item names (again, preferences. It's Alvis's Barhara BBQ, with some Falaflame.)
Class names (Preferences might be a bit less Japanese here. It's Hero, not Forrest.)
Menus (title menu aside. It's in dialogue format.) Some menus here aren't translated in the old patch, so enjoy English unit menu for those who can't run PN! (If you can run PN, run PN. It's a lot fancier. This patch ain't based on PN, though.)

IT'S IN ENGLISH, BUT ROUGH:
Terrain names (not much space here)
Castle names (more space, but there's missing letters every so often)
Army names (It's Sigur phase, unfortunately)
Gen 2 enemies (I'll polish it up later. Hopefully.)
Town commands (Things overlap a bit in some menus.)
Title screen (Hideous. But English.)
Title cards (Yeah, I know Ch1 is missing the 1.)

STILL IN JAPANESE:
Dialogue. The entire plot is still in Japanese and completely unreadable to those who need this patch. It's not like the plot's changed any.
Random system messages and whatnot that pop up in combat.
THE PROMOTION SCREEN. Be careful when promoting, and refer to the Binary LP.
For that matter, all town services use dialogue coding and are in Japanese as a result.
New game menu. Why? Because again, dialogue coding.

SO HOW DO I PATCH THIS OLD THING?
Apply the patch to a vanilla Japanese rom. A HEADERED Japanese rom. The filesize is 4,194,816 bytes. If your rom has a byte count in the 300s at the end, that means it's unheadered. Which is bad. Go look up a tool that can add a header. (I used a dusty thing called SNESTool way back when. It's a DOS tool. Go get something fancier.) Don't forget to download Lunar IPS to patch the file! If you already have a Japanese copy of Binary, you can apply the "Jpn to Eng.ips" file. If you wanna use the UPS file, that's what NUPS is for. They're important!

ANYTHING ELSE?
If you wanna keep up with any shenagains I get up to, you can find it first at http://feuniverse.us/t/fire-emblem-4-binary-english-translation-v0-1/2487
And before anyone complains about names, she's Fury. Should you not like that, paste in the following hex code at 0x39793 in the rom once you've patched it: 82A8 8363 8350 835A.
I hope I didn't make anyone too erinous with that decision.
- Darrman