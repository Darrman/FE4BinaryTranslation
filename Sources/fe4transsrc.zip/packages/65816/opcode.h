#ifndef __opcode_
#define __opcode_

#define OPCODEMAX 100 

int opcode(char *);

#endif
