#ifndef __list_
#define __list_

#include "machine.h"

int	listOpenFile(char *);
void 	listCloseFile(void);
void	listCleanUp(void);
int 	listPutLine(char *);
	

#endif
