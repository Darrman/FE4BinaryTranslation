#ifndef __directives_
#define __directives_

#define BIN "BIN"
#define INC "INL"
#define ORG "ORG"
#define PAD "PAD"
#define EQU "EQU"
#define DCB "DCB"
#define DCW "DCW"
#define DCD "DCD"

#endif
