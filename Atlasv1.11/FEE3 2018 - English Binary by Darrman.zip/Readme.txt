FIRE EMBLEM BINARY, ENGLISH TRANSLATION
FEE3 2018 BUILD, 14/10/'18

Apply patch to a clean Japanese headered FE4 rom. Other patches can be provided upon request.
The patch is an IPS file. You can apply it with Lunar IPS, or you can just rename it to the same as your rom and it should patch automatically.
Patch and save tested on ZSNES and BSNES+. SNES9x has not been tested, but it should work fine there as well.
For the presentation, please load file 2 as I feel that shows off the game best from what I have translated. Don't forget to check inside the home castle!
Load File 1 if you feel like having a barbeque, and start a new game to get credits.
A more verbose variant of the credits will be posted below.
// 0xd9eb8
#W16($11B556)
// @@1160534@@
FEE3 2018 Build - Credits

Translated: Chapters 0-3, Chapter 5
All shops and menus (eg: stat screens, promotion menu)
Some graphics, like title screen and chapter cards

Untranslated: Chapter 4, Chapters 6-11
All boss and death quotes, boss quotes load random dialogue from elsewhere
Almost all talks
Script is severly truncated due to space limitations
There's some humourous replacements around, though

Please load save 2
Save 1 for a BBQ

Project Naga, Fire Emblem Heroes, and other such terminology will be ignored here

Based on Reperation version 0.87g,
along with all its source files
Reperation in turn is based on J2E Renegade version 0.50.9.1
Credit to Jay, Boo and Twilkitri for their work on originally translating FE4, and for making sources freely available

Credit to the original hacker, Habana?887.bsRoNI, for creating hack

English Binary translation by Darrman.
Let's all hope nothing explodes.
